const DEFAULTS = { enabled: true, port: 49731 };
const $ = (id) => document.getElementById(id);

async function check() {
  const box = $("status");
  box.className = "status";
  $("statusText").textContent = "Checking…";
  const port = Number($("port").value) || DEFAULTS.port;
  try {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 2000);
    const r = await fetch(`http://127.0.0.1:${port}/ping`, { signal: ctrl.signal });
    if (!r.ok) {
      box.className = "status bad";
      $("statusText").textContent =
        `App answered but refused (HTTP ${r.status}). Use the latest app files and rebuild it.`;
      return;
    }
    box.className = "status ok";
    $("statusText").textContent = "Connected to TurboDownload Pro";
  } catch (e) {
    box.className = "status bad";
    $("statusText").textContent =
      `Cannot reach the app on port ${port}. Open the NEW TurboDownload Pro (with the browser link line).`;
  }
}

async function init() {
  const s = await chrome.storage.local.get(DEFAULTS);
  $("enabled").checked = s.enabled;
  $("port").value = s.port;
  check();
}

$("enabled").addEventListener("change", () =>
  chrome.storage.local.set({ enabled: $("enabled").checked }));
$("port").addEventListener("change", async () => {
  const p = Number($("port").value);
  if (p >= 1024 && p <= 65535) await chrome.storage.local.set({ port: p });
  check();
});
$("test").addEventListener("click", check);
init();
