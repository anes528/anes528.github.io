// TurboDownload Connector — background service worker (Chrome / Edge, Manifest V3)
// يلتقط أي تحميل يبدأ في المتصفح ويرسله إلى برنامج TurboDownload Pro المفتوح على جهازك.
// الأمان من الفشل: إذا كان البرنامج مغلقاً، أو رفض الموقع طلب البرنامج قبل أن يبدأ،
// يُعاد التحميل تلقائياً إلى المتصفح فلا يضيع منك أي تحميل.

const DEFAULTS = { enabled: true, port: 49731 };
const getSettings = () => chrome.storage.local.get(DEFAULTS);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const bypass = new Set();            // روابط أعدناها للمتصفح عمداً (حتى لا نلتقطها مرة ثانية)

function norm(u) {
  try { return new URL(u).href; } catch (e) { return u; }
}

async function appFetch(path, options) {
  const { port } = await getSettings();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 2500);
  try {
    return await fetch(`http://127.0.0.1:${port}${path}`, { ...options, signal: ctrl.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function appIsUp() {
  try {
    const r = await appFetch("/ping");
    return r.ok;
  } catch (e) {
    return false;
  }
}

function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}

// كوكيز كل رابط (الأصلي والنهائي بعد التحويلات) مع نطاقاتها، ليستعملها البرنامج بدقة
async function collectCookies(urls) {
  const seen = new Map();
  for (const u of urls) {
    try {
      const list = await chrome.cookies.getAll({ url: u });
      for (const c of list) {
        const key = `${c.domain}|${c.path}|${c.name}`;
        if (!seen.has(key)) {
          seen.set(key, { name: c.name, value: c.value, domain: c.domain, path: c.path });
        }
      }
    } catch (e) { /* بدون كوكيز */ }
  }
  return [...seen.values()];
}

async function sendToApp(url, referrer, extraUrls = []) {
  const job = {
    id: newId(),
    url,
    referrer: referrer || "",
    cookies: await collectCookies([url, ...extraUrls]),
    userAgent: navigator.userAgent,
  };
  const r = await appFetch("/add", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(job),
  });
  if (!r.ok) throw new Error("TurboDownload refused the link (" + r.status + ")");
  return job.id;
}

function flash(text, color, ms = 3500) {
  chrome.action.setBadgeBackgroundColor({ color });
  chrome.action.setBadgeText({ text });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), ms);
}

// إعادة التحميل للمتصفح (مع تجاوز الالتقاط حتى لا نعيده للبرنامج)
function handBackToBrowser(url) {
  const key = norm(url);
  bypass.add(key);
  setTimeout(() => bypass.delete(key), 60000);
  chrome.downloads.download({ url });
  flash("!", "#f59e0b", 5000);
}

// يراقب البرنامج ~25 ثانية: إذا فشل قبل أن يبدأ التحميل (مثلاً الموقع رفض)، يكمل المتصفح
async function watchJob(id, browserUrl) {
  for (let i = 0; i < 25; i++) {
    await sleep(1000);
    let state = "unknown";
    try {
      const r = await appFetch(`/result?id=${encodeURIComponent(id)}`);
      state = (await r.json()).state;
    } catch (e) {
      return;                                   // البرنامج أُغلق أو لا يرد
    }
    if (state === "started" || state === "cancelled") return;
    if (state === "failed") {
      handBackToBrowser(browserUrl);
      return;
    }
  }
}

// ---------------------------------------------------------------- التقاط التحميلات
chrome.downloads.onCreated.addListener(async (item) => {
  const { enabled } = await getSettings();
  if (!enabled) return;

  const original = item.url || "";
  const finalUrl = item.finalUrl || original;
  if (bypass.delete(norm(original)) || bypass.delete(norm(finalUrl))) return;
  if (!/^https?:\/\//i.test(original)) return;      // blob: و data: و file: يبقى في المتصفح

  if (!(await appIsUp())) {                    // البرنامج مغلق → المتصفح يكمل التحميل
    flash("!", "#ef4444");
    return;
  }

  // أوقف تحميل المتصفح ثم سلّم الرابط للبرنامج
  try {
    await chrome.downloads.cancel(item.id);
    await chrome.downloads.erase({ id: item.id });
  } catch (e) { /* قد يكون انتهى فعلاً (ملف صغير جداً) */ }

  const jobUrl = /^https?:\/\//i.test(finalUrl) ? finalUrl : original;
  try {
    const id = await sendToApp(jobUrl, item.referrer, [original]);
    flash("↓", "#22c55e", 2500);
    watchJob(id, original);
  } catch (e) {
    handBackToBrowser(original);               // احتياط: لا نترك المستخدم بلا تحميل
  }
});

// ---------------------------------------------------------------- قائمة الزر الأيمن
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "turbo-send",
    title: "Download with TurboDownload",
    contexts: ["link", "image", "video", "audio"],
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "turbo-send") return;
  const url = info.linkUrl || info.srcUrl;
  if (!url || !/^https?:\/\//i.test(url)) return;
  try {
    if (!(await appIsUp())) throw new Error("app is not running");
    await sendToApp(url, info.pageUrl || (tab && tab.url) || "");
    flash("↓", "#22c55e", 2500);
  } catch (e) {
    flash("!", "#ef4444");
  }
});
